-- constraints_test.sql
-- These statements are supposed to fail
-- 1. Invalid status value
INSERT INTO AdoptionApplication (user_id, pet_id, status, submitted_at, notes)
VALUES (
        1,
        101,
        'In Review',
        NOW(),
        'Should fail because status is not allowed'
    );
-- 2. Foreign key failure: user_id does not exist
INSERT INTO AdoptionApplication (user_id, pet_id, status, submitted_at, notes)
VALUES (
        999,
        101,
        'Pending',
        NOW(),
        'Should fail because user does not exist'
    );
-- 3. Check constraint failure: negative age
INSERT INTO Pet (pet_id, name, species, age, available)
VALUES (106, 'Shadow', 'Dog', -1, TRUE);
-- 4. Unique constraint failure: duplicate email
INSERT INTO UserTable (user_id, name, email)
VALUES (5, 'Emma Brown', 'alice@example.com');